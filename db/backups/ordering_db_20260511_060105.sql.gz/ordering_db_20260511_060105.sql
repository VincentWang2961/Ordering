--
-- PostgreSQL database dump
--

\restrict qFTfONzMwNkjZAdDeaXTyrirD7JNfKl8gSt77JwPCJOerY3JNtHtgMes3vYxJZc

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: audit_trigger_func(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.audit_trigger_func() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    _user_id UUID;
    _old_json JSONB;
    _new_json JSONB;
BEGIN
    -- Get current user ID from application context (set via SET LOCAL)
    _user_id := current_setting('app.current_user_id', true)::UUID;

    IF TG_OP = 'INSERT' THEN
        _new_json := to_jsonb(NEW);
        INSERT INTO audit_log (table_name, record_id, action, new_data, changed_by)
        VALUES (TG_TABLE_NAME, NEW.id::VARCHAR, 'INSERT', _new_json, _user_id);
        RETURN NEW;

    ELSIF TG_OP = 'UPDATE' THEN
        _old_json := to_jsonb(OLD);
        _new_json := to_jsonb(NEW);
        INSERT INTO audit_log (table_name, record_id, action, old_data, new_data, changed_by)
        VALUES (TG_TABLE_NAME, OLD.id::VARCHAR, 'UPDATE', _old_json, _new_json, _user_id);
        RETURN NEW;

    ELSIF TG_OP = 'DELETE' THEN
        _old_json := to_jsonb(OLD);
        INSERT INTO audit_log (table_name, record_id, action, old_data, changed_by)
        VALUES (TG_TABLE_NAME, OLD.id::VARCHAR, 'DELETE', _old_json, _user_id);
        RETURN OLD;
    END IF;

    RETURN NULL;
END;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    table_name character varying(100) NOT NULL,
    record_id character varying(100) NOT NULL,
    action character varying(20) NOT NULL,
    old_data jsonb,
    new_data jsonb,
    changed_by uuid,
    ip_address character varying(45),
    changed_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT audit_log_action_check CHECK (((action)::text = ANY ((ARRAY['INSERT'::character varying, 'UPDATE'::character varying, 'DELETE'::character varying])::text[])))
);


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: financial_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.financial_records (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    order_id character varying(50),
    type character varying(50) NOT NULL,
    amount numeric(12,2) NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    recorded_by uuid,
    recorded_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT financial_records_type_check CHECK (((type)::text = ANY ((ARRAY['order_revenue'::character varying, 'delivery_fee'::character varying, 'refund'::character varying, 'expense_ingredient'::character varying, 'expense_operation'::character varying, 'expense_other'::character varying, 'adjustment'::character varying])::text[])))
);


--
-- Name: menu_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.menu_items (
    id character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    name_zh_cn character varying(200) DEFAULT ''::character varying NOT NULL,
    name_zh_tw character varying(200) DEFAULT ''::character varying NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    description_zh_cn text DEFAULT ''::text NOT NULL,
    description_zh_tw text DEFAULT ''::text NOT NULL,
    price numeric(10,2) NOT NULL,
    image character varying(500) DEFAULT ''::character varying NOT NULL,
    category character varying(100) DEFAULT ''::character varying NOT NULL,
    published boolean DEFAULT true NOT NULL,
    available_start_date date,
    available_end_date date,
    available_days integer[] DEFAULT '{}'::integer[],
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT menu_items_price_check CHECK ((price >= (0)::numeric))
);


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_items (
    id integer NOT NULL,
    order_id character varying(50) NOT NULL,
    menu_id character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    quantity integer NOT NULL,
    price numeric(10,2) NOT NULL,
    CONSTRAINT order_items_price_check CHECK ((price >= (0)::numeric)),
    CONSTRAINT order_items_quantity_check CHECK ((quantity > 0))
);


--
-- Name: order_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.order_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.order_items_id_seq OWNED BY public.order_items.id;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    id character varying(50) NOT NULL,
    contact character varying(200) NOT NULL,
    address character varying(500) NOT NULL,
    lat numeric(10,7),
    lng numeric(10,7),
    pickup_time character varying(20) DEFAULT ''::character varying NOT NULL,
    notes text DEFAULT ''::text NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    total numeric(10,2) DEFAULT 0 NOT NULL,
    paid boolean DEFAULT false NOT NULL,
    paid_at timestamp with time zone,
    delivered_at timestamp with time zone,
    delivered_photo text,
    delivery_comment text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT orders_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'accepted'::character varying, 'cancelled'::character varying, 'delivered'::character varying])::text[]))),
    CONSTRAINT orders_total_check CHECK ((total >= (0)::numeric))
);


--
-- Name: restaurant_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.restaurant_settings (
    id integer NOT NULL,
    key character varying(100) NOT NULL,
    value text DEFAULT ''::text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: restaurant_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.restaurant_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: restaurant_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.restaurant_settings_id_seq OWNED BY public.restaurant_settings.id;


--
-- Name: route_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.route_plans (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    user_id uuid NOT NULL,
    restaurant_address character varying(500) NOT NULL,
    end_address character varying(500),
    selected_order_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    route_result jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    display_name character varying(100) NOT NULL,
    role character varying(20) DEFAULT 'admin'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['superadmin'::character varying, 'admin'::character varying])::text[])))
);


--
-- Name: v_daily_revenue; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_daily_revenue AS
 SELECT date(recorded_at) AS day,
    type,
    sum(amount) AS total_amount,
    count(*) AS transaction_count
   FROM public.financial_records
  GROUP BY (date(recorded_at)), type
  ORDER BY (date(recorded_at)) DESC;


--
-- Name: v_order_performance; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.v_order_performance AS
 SELECT date(created_at) AS day,
    status,
    count(*) AS order_count,
    sum(total) AS total_revenue,
    avg(total) AS avg_order_value
   FROM public.orders
  GROUP BY (date(created_at)), status
  ORDER BY (date(created_at)) DESC;


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: order_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items ALTER COLUMN id SET DEFAULT nextval('public.order_items_id_seq'::regclass);


--
-- Name: restaurant_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_settings ALTER COLUMN id SET DEFAULT nextval('public.restaurant_settings_id_seq'::regclass);


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_log (id, table_name, record_id, action, old_data, new_data, changed_by, ip_address, changed_at) FROM stdin;
1	users	5e0bd7b3-5c78-442d-b0fb-f44464063fad	INSERT	\N	{"id": "5e0bd7b3-5c78-442d-b0fb-f44464063fad", "role": "superadmin", "email": "admin@ordering.app", "username": "admin", "is_active": true, "created_at": "2026-05-11T05:57:40.971776+00:00", "updated_at": "2026-05-11T05:57:40.971776+00:00", "display_name": "Super Admin", "last_login_at": null, "password_hash": "$2a$06$LLTVRVstzZfnjnmgJGi8pOf2ytla6OWWu7Ecjt/eaJo/OtFRPMV0i"}	\N	\N	2026-05-11 05:57:40.971776+00
2	users	0cbc63c3-1a83-4f9a-b531-b2462862cc31	INSERT	\N	{"id": "0cbc63c3-1a83-4f9a-b531-b2462862cc31", "role": "admin", "email": "vincent@vincentwang.au", "username": "vincent", "is_active": true, "created_at": "2026-05-11T05:57:40.979215+00:00", "updated_at": "2026-05-11T05:57:40.979215+00:00", "display_name": "Vincent Wang", "last_login_at": null, "password_hash": "$2a$06$TKQRYgqbXVk3DtgoqVeMCO9x7tEsve5j49Mvh/yDqiYzpywyurbPm"}	\N	\N	2026-05-11 05:57:40.979215+00
\.


--
-- Data for Name: financial_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.financial_records (id, order_id, type, amount, description, recorded_by, recorded_at) FROM stdin;
\.


--
-- Data for Name: menu_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.menu_items (id, name, name_zh_cn, name_zh_tw, description, description_zh_cn, description_zh_tw, price, image, category, published, available_start_date, available_end_date, available_days, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_items (id, order_id, menu_id, name, quantity, price) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orders (id, contact, address, lat, lng, pickup_time, notes, status, total, paid, paid_at, delivered_at, delivered_photo, delivery_comment, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: restaurant_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.restaurant_settings (id, key, value, updated_at) FROM stdin;
1	name	Ordering	2026-05-11 05:57:37.003257+00
2	name_zh_cn	Ordering	2026-05-11 05:57:37.003257+00
3	name_zh_tw	Ordering	2026-05-11 05:57:37.003257+00
4	pickup_address	Perth WA, Australia	2026-05-11 05:57:37.003257+00
5	pickup_address_zh_cn	Perth WA, Australia	2026-05-11 05:57:37.003257+00
6	pickup_address_zh_tw	Perth WA, Australia	2026-05-11 05:57:37.003257+00
7	contact	0488888888	2026-05-11 05:57:37.003257+00
\.


--
-- Data for Name: route_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.route_plans (id, user_id, restaurant_address, end_address, selected_order_ids, route_result, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, email, password_hash, display_name, role, is_active, last_login_at, created_at, updated_at) FROM stdin;
5e0bd7b3-5c78-442d-b0fb-f44464063fad	admin	admin@ordering.app	$2a$06$LLTVRVstzZfnjnmgJGi8pOf2ytla6OWWu7Ecjt/eaJo/OtFRPMV0i	Super Admin	superadmin	t	\N	2026-05-11 05:57:40.971776+00	2026-05-11 05:57:40.971776+00
0cbc63c3-1a83-4f9a-b531-b2462862cc31	vincent	vincent@vincentwang.au	$2a$06$TKQRYgqbXVk3DtgoqVeMCO9x7tEsve5j49Mvh/yDqiYzpywyurbPm	Vincent Wang	admin	t	\N	2026-05-11 05:57:40.979215+00	2026-05-11 05:57:40.979215+00
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 2, true);


--
-- Name: order_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.order_items_id_seq', 1, false);


--
-- Name: restaurant_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.restaurant_settings_id_seq', 7, true);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: financial_records financial_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_records
    ADD CONSTRAINT financial_records_pkey PRIMARY KEY (id);


--
-- Name: menu_items menu_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT menu_items_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: restaurant_settings restaurant_settings_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_settings
    ADD CONSTRAINT restaurant_settings_key_key UNIQUE (key);


--
-- Name: restaurant_settings restaurant_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.restaurant_settings
    ADD CONSTRAINT restaurant_settings_pkey PRIMARY KEY (id);


--
-- Name: route_plans route_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.route_plans
    ADD CONSTRAINT route_plans_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_audit_log_changed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_log_changed_at ON public.audit_log USING btree (changed_at);


--
-- Name: idx_audit_log_record_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_log_record_id ON public.audit_log USING btree (record_id);


--
-- Name: idx_audit_log_table; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_log_table ON public.audit_log USING btree (table_name);


--
-- Name: idx_financial_records_recorded_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_financial_records_recorded_at ON public.financial_records USING btree (recorded_at);


--
-- Name: idx_financial_records_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_financial_records_type ON public.financial_records USING btree (type);


--
-- Name: idx_menu_items_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_menu_items_category ON public.menu_items USING btree (category);


--
-- Name: idx_menu_items_published; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_menu_items_published ON public.menu_items USING btree (published);


--
-- Name: idx_order_items_order_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_order_items_order_id ON public.order_items USING btree (order_id);


--
-- Name: idx_orders_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_created_at ON public.orders USING btree (created_at);


--
-- Name: idx_orders_pickup_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_pickup_time ON public.orders USING btree (pickup_time);


--
-- Name: idx_orders_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orders_status ON public.orders USING btree (status);


--
-- Name: idx_route_plans_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_route_plans_user_id ON public.route_plans USING btree (user_id);


--
-- Name: financial_records audit_financial_records; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_financial_records AFTER INSERT OR DELETE OR UPDATE ON public.financial_records FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();


--
-- Name: menu_items audit_menu_items; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_menu_items AFTER INSERT OR DELETE OR UPDATE ON public.menu_items FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();


--
-- Name: order_items audit_order_items; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_order_items AFTER INSERT OR DELETE OR UPDATE ON public.order_items FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();


--
-- Name: orders audit_orders; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_orders AFTER INSERT OR DELETE OR UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();


--
-- Name: restaurant_settings audit_restaurant_settings; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_restaurant_settings AFTER INSERT OR DELETE OR UPDATE ON public.restaurant_settings FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();


--
-- Name: users audit_users; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_users AFTER INSERT OR DELETE OR UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_func();


--
-- Name: menu_items trg_menu_items_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_menu_items_updated_at BEFORE UPDATE ON public.menu_items FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: orders trg_orders_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_orders_updated_at BEFORE UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: restaurant_settings trg_restaurant_settings_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_restaurant_settings_updated_at BEFORE UPDATE ON public.restaurant_settings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users trg_users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: audit_log audit_log_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id);


--
-- Name: financial_records financial_records_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_records
    ADD CONSTRAINT financial_records_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: financial_records financial_records_recorded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_records
    ADD CONSTRAINT financial_records_recorded_by_fkey FOREIGN KEY (recorded_by) REFERENCES public.users(id);


--
-- Name: order_items order_items_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: orders orders_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: route_plans route_plans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.route_plans
    ADD CONSTRAINT route_plans_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict qFTfONzMwNkjZAdDeaXTyrirD7JNfKl8gSt77JwPCJOerY3JNtHtgMes3vYxJZc

